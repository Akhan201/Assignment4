/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany;
import javax.swing.*;
import java.awt.*;  
/**
 *
 * @author gobik
 */
public class CashRegister extends JFrame
 {
private Display display = new Display();
private TicketPrinter ticketPrinter = new TicketPrinter();
private Product currentProduct;
private ProductDB productDB = new ProductDB();
private int UPCCode;

public void setCurrentProductUPC(int UPCCode)
 {
this.UPCCode = UPCCode;
this.currentProduct = this.getCurrentProductInfo();


if (this.currentProduct != null)
{
this.display.displayText(this.currentProduct.toString());
this.ticketPrinter.displayText(this.currentProduct.toString());
}
}
public Product getCurrentProductInfo()
{
currentProduct = this.productDB.GetProductInfo(this.UPCCode);
return currentProduct;
}
 private void init() {
        setLayout(new FlowLayout());
        //change text later
        add(new JLabel("Welcome to " + CashRegister));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(640, 480);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CashRegister().setVisible(true);
                
                
                //add J Text Field https://docs.oracle.com/javase/tutorial/uiswing/components/textfield.html
                
            }
}
                }
    


                }


