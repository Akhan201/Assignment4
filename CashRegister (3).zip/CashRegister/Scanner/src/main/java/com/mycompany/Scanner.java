/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany;

import java.awt.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
/**
 *
 * @author gobik
 */
public class Scanner implements ActionListener
{
    //make a GUI
public Scanner() {
JFrame frame = new JFrame();
JPanel panel = new JPanel();
//in pixels
panel.setBorder(BorderFactory.createEmptyBorder(40,40,20,40));
//set layout
panel.setLayout(new GridLayout(0,1));

frame.setSize(100,100);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.add(panel);   
frame.setTitle("Scanner");

panel.setLayout(null);

JLabel label = new JLabel("Enter a UPC code");
label.setBounds(20,50,90,30);
panel.add(label);


JTextField ScannerText = new JTextField(5);
ScannerText.setBounds(90,50,150,30);
panel.add(ScannerText);

JButton button = new JButton("Confirm");
button.setBounds(20,70,70,30);
button.addActionListener(new Scanner()); 
panel.add(button);


frame.setVisible(true);


}
public static void main(String[] args) {
    //CREATES NEW GUI OBJECT FROM THE GUI CLASS
        new Scanner();

}

    @Override
    public void actionPerformed(ActionEvent e) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       
       String gui; 
  
    }



}
